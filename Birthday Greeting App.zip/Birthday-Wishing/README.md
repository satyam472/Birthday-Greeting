# Birthday-Wishing
A simple Android App to wish your friends Happy Birthday!

Youtube playlist for this Project: https://bit.ly/2DKn7N5
</br>
</br>
[![Watch the video](https://img.youtube.com/vi/YV4i_ksoe-Q/hqdefault.jpg)](https://youtu.be/YV4i_ksoe-Q)
